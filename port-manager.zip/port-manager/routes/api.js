/**
 * Pterodactyl Application API integration routes.
 *
 * Handles the core "Assign Port" workflow:
 *  1. Look up the target server to find its node/allocation info.
 *  2. Check existing allocations on that node for the requested IP/port.
 *  3. Create the allocation on the node if it does not already exist.
 *  4. Assign the allocation to the server.
 *
 * All requests to Pterodactyl use the Application API key stored in
 * config.json (Authorization: Bearer <apiKey>).
 */

const express = require('express');
const axios = require('axios');
const { loadConfig } = require('./config');

const router = express.Router();

// Build a pre-configured axios client for the Pterodactyl Application API.
function getClient() {
  const config = loadConfig();

  if (!config.panelUrl || !config.apiKey) {
    return null;
  }

  return axios.create({
    baseURL: `${config.panelUrl}/api/application`,
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      Accept: 'Application/vnd.pterodactyl.v1+json',
      'Content-Type': 'application/json',
    },
    timeout: 15000,
  });
}

// Strictly validate an IPv4 address (each octet must be 0-255, no leading
// zeros ambiguity, exactly 4 octets).
function isValidIPv4(value) {
  const parts = value.split('.');
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    // Reject empty, non-digit, or leading-zero segments (e.g. "01").
    if (!/^\d{1,3}$/.test(part)) return false;
    if (part.length > 1 && part[0] === '0') return false;
    const num = Number(part);
    return num >= 0 && num <= 255;
  });
}

// Extract a human-readable error message from an axios error.
function extractErrorMessage(err) {
  if (err.response && err.response.data) {
    const data = err.response.data;
    if (data.errors && Array.isArray(data.errors) && data.errors.length > 0) {
      return data.errors.map((e) => e.detail || e.code).join('; ');
    }
    if (data.message) return data.message;
    return JSON.stringify(data);
  }
  if (err.code === 'ECONNABORTED') return 'Request to the Pterodactyl panel timed out.';
  if (err.code === 'ENOTFOUND' || err.code === 'ECONNREFUSED') {
    return 'Could not reach the Pterodactyl panel. Check the Panel URL.';
  }
  return err.message || 'Unknown error contacting the Pterodactyl panel.';
}

// POST /api/assign-port - Main port assignment workflow.
router.post('/assign-port', async (req, res) => {
  const { serverId, nodeIp, port } = req.body;

  // --- Input validation ---
  if (!serverId || !nodeIp || !port) {
    return res.status(400).json({ success: false, message: 'Server ID, Node IP, and Port are all required.' });
  }

  const serverIdNum = parseInt(serverId, 10);
  const portNum = parseInt(port, 10);

  if (Number.isNaN(serverIdNum) || serverIdNum <= 0) {
    return res.status(400).json({ success: false, message: 'Server ID must be a positive number.' });
  }
  if (Number.isNaN(portNum) || portNum < 1 || portNum > 65535) {
    return res.status(400).json({ success: false, message: 'Port must be a number between 1 and 65535.' });
  }
  if (!isValidIPv4(nodeIp.trim())) {
    return res.status(400).json({ success: false, message: 'Node IP must be a valid IPv4 address.' });
  }

  const client = getClient();
  if (!client) {
    return res.status(400).json({
      success: false,
      message: 'Panel URL and API key are not configured yet. Please set them up first.',
    });
  }

  try {
    // Step 1: Fetch the server to determine which node it lives on.
    const serverResp = await client.get(`/servers/${serverIdNum}`);
    const serverData = serverResp.data.attributes;
    const nodeId = serverData.node;

    // Step 2: Fetch existing allocations for that node to see if the
    // requested ip/port combination already exists.
    const allocationsResp = await client.get(`/nodes/${nodeId}/allocations`, {
      params: { per_page: 10000 },
    });

    const allocations = allocationsResp.data.data || [];
    let allocation = allocations.find(
      (a) => a.attributes.ip === nodeIp.trim() && a.attributes.port === portNum
    );

    let created = false;

    // Step 3: Create the allocation if it does not exist yet.
    if (!allocation) {
      const createResp = await client.post(`/nodes/${nodeId}/allocations`, {
        ip: nodeIp.trim(),
        ports: [String(portNum)],
      });
      created = true;

      // Re-fetch allocations to get the newly created allocation's ID
      // (the create endpoint does not always return the allocation object).
      const refreshed = await client.get(`/nodes/${nodeId}/allocations`, {
        params: { per_page: 10000 },
      });
      const refreshedAllocations = refreshed.data.data || [];
      allocation = refreshedAllocations.find(
        (a) => a.attributes.ip === nodeIp.trim() && a.attributes.port === portNum
      );

      if (!allocation) {
        return res.status(500).json({
          success: false,
          message: 'Allocation was created but could not be located afterward. Please check the panel manually.',
        });
      }
    } else if (allocation.attributes.assigned) {
      // The allocation exists but is already assigned to some server.
      return res.status(409).json({
        success: false,
        message: `Allocation ${nodeIp}:${portNum} already exists and is currently assigned to another server.`,
      });
    }

    // Step 4: Assign the allocation to the target server.
    // Pterodactyl's application API assigns allocations by updating the
    // server's build configuration, adding the allocation ID.
    const currentAllocationIds = (serverData.relationships &&
      serverData.relationships.allocations &&
      serverData.relationships.allocations.data
      ? serverData.relationships.allocations.data.map((a) => a.attributes.id)
      : []
    );

    const allocationId = allocation.attributes.id;
    const newAllocationIds = Array.from(new Set([...currentAllocationIds, allocationId]));

    const assignResp = await client.patch(`/servers/${serverIdNum}/build`, {
      allocation: serverData.allocation, // keep existing primary allocation
      add_allocations: [allocationId],
      remove_allocations: [],
      memory: serverData.limits.memory,
      swap: serverData.limits.swap,
      disk: serverData.limits.disk,
      io: serverData.limits.io,
      cpu: serverData.limits.cpu,
    });

    return res.json({
      success: true,
      message: created
        ? `Allocation ${nodeIp}:${portNum} was created and assigned to server #${serverIdNum}.`
        : `Existing allocation ${nodeIp}:${portNum} was assigned to server #${serverIdNum}.`,
      data: {
        allocationId,
        created,
        response: assignResp.data,
      },
    });
  } catch (err) {
    console.error('Assign port error:', extractErrorMessage(err));
    return res.status(err.response ? err.response.status || 500 : 500).json({
      success: false,
      message: extractErrorMessage(err),
    });
  }
});

module.exports = router;
