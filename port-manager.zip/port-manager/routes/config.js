/**
 * Configuration routes.
 *
 * Handles reading and saving the Pterodactyl panel connection settings
 * (panel URL + application API key) which are persisted in config.json.
 */

const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const CONFIG_FILE = path.join(__dirname, '..', 'config.json');

// Read the current configuration from disk. Returns default empty values
// if the file does not exist yet.
function loadConfig() {
  try {
    const raw = fs.readFileSync(CONFIG_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    return { panelUrl: '', apiKey: '' };
  }
}

// Persist the configuration object to config.json.
function saveConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
}

// GET /api/config - Return the current configuration.
// The API key is partially masked for display purposes unless "reveal" is not requested.
router.get('/config', (req, res) => {
  const config = loadConfig();
  res.json({
    success: true,
    config: {
      panelUrl: config.panelUrl || '',
      apiKey: config.apiKey || '',
    },
  });
});

// POST /api/config - Save/update the panel URL and API key.
router.post('/config', (req, res) => {
  const { panelUrl, apiKey } = req.body;

  // Validate presence.
  if (!panelUrl || !apiKey || typeof panelUrl !== 'string' || typeof apiKey !== 'string') {
    return res.status(400).json({ success: false, message: 'Panel URL and API key are required.' });
  }

  const trimmedUrl = panelUrl.trim().replace(/\/+$/, ''); // strip trailing slashes
  const trimmedKey = apiKey.trim();

  // Basic sanity checks. Only allow http/https schemes so a malicious or
  // malformed value can't point the app at an unexpected protocol.
  let parsedUrl;
  try {
    parsedUrl = new URL(trimmedUrl);
  } catch (err) {
    return res.status(400).json({ success: false, message: 'Panel URL must be a valid URL.' });
  }
  if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
    return res.status(400).json({ success: false, message: 'Panel URL must use http:// or https://.' });
  }

  if (!trimmedKey.startsWith('ptla_')) {
    return res.status(400).json({ success: false, message: 'Application API key must start with "ptla_".' });
  }

  const config = { panelUrl: trimmedUrl, apiKey: trimmedKey };

  try {
    saveConfig(config);
    return res.json({ success: true, message: 'Configuration saved successfully.', config });
  } catch (err) {
    console.error('Failed to save config:', err);
    return res.status(500).json({ success: false, message: 'Failed to save configuration.' });
  }
});

module.exports = { router, loadConfig };
