/**
 * Authentication routes: login and logout.
 *
 * Users are stored in users.json with bcrypt-hashed passwords.
 * Sessions are managed with express-session (configured in server.js).
 */

const express = require('express');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const USERS_FILE = path.join(__dirname, '..', 'users.json');

// Load the list of users from users.json.
function loadUsers() {
  try {
    const raw = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    // If the file is missing or corrupt, fail safe with no users.
    console.error('Failed to read users.json:', err.message);
    return [];
  }
}

// POST /api/login - Validate credentials and create a session.
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // Basic input validation.
  if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ success: false, message: 'Username and password are required.' });
  }

  const users = loadUsers();
  const user = users.find((u) => u.username === username.trim());

  if (!user) {
    // Do not reveal whether the username exists.
    return res.status(401).json({ success: false, message: 'Invalid username or password.' });
  }

  try {
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }

    // Regenerate the session to prevent session fixation attacks.
    req.session.regenerate((err) => {
      if (err) {
        console.error('Session regenerate error:', err);
        return res.status(500).json({ success: false, message: 'Could not create session.' });
      }
      req.session.user = { username: user.username };
      return res.json({ success: true, message: 'Login successful.' });
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Server error during login.' });
  }
});

// POST /api/logout - Destroy the current session.
router.post('/logout', (req, res) => {
  if (!req.session) {
    return res.json({ success: true, message: 'Already logged out.' });
  }
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({ success: false, message: 'Could not log out.' });
    }
    res.clearCookie('connect.sid');
    return res.json({ success: true, message: 'Logged out successfully.' });
  });
});

// GET /api/session - Report whether the client currently has an active session.
router.get('/session', (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ success: true, user: req.session.user });
  }
  return res.status(401).json({ success: false, message: 'Not authenticated.' });
});

module.exports = router;
