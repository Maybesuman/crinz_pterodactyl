/**
 * Pterodactyl Port Manager - main server entry point.
 *
 * Sets up Express, session management, static file serving, and mounts
 * the auth/config/api routers. Also protects dashboard/setup pages so
 * only authenticated users can reach them.
 */

const express = require('express');
const session = require('express-session');
const path = require('path');
const crypto = require('crypto');

const authRoutes = require('./routes/auth');
const { router: configRoutes } = require('./routes/config');
const apiRoutes = require('./routes/api');
const { requireAuth } = require('./middleware/auth');

const app = express();
const PORT = 1000;

// --- Core middleware ---
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --- Session secret ---
// A strong secret is required. If SESSION_SECRET is not provided via the
// environment, generate a random one at boot so sessions are never signed
// with a known/guessable value. Note: this means sessions won't survive a
// restart unless SESSION_SECRET is set explicitly in the environment.
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
if (!process.env.SESSION_SECRET) {
  console.warn('WARNING: SESSION_SECRET is not set. Using a random secret generated at startup ' +
    '(sessions will be invalidated on restart). Set SESSION_SECRET in the environment for production.');
}

// --- Session configuration ---
// Sessions are stored server-side (default in-memory store is fine for
// this single-instance app). The cookie is HttpOnly to reduce XSS risk,
// and SameSite=Lax mitigates cross-site request forgery for cookie-based
// auth on top of the explicit CSRF token check below.
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // set to true if served exclusively over HTTPS
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 8, // 8 hour session
    },
  })
);

// --- CSRF protection ---
// Issues a per-session token and validates it on all state-changing
// (non-GET) API requests. The token is exposed to the frontend via
// GET /api/csrf-token and must be echoed back in the X-CSRF-Token header.
app.get('/api/csrf-token', (req, res) => {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(24).toString('hex');
  }
  res.json({ success: true, csrfToken: req.session.csrfToken });
});

function verifyCsrf(req, res, next) {
  const headerToken = req.headers['x-csrf-token'];
  if (!req.session.csrfToken || !headerToken || headerToken !== req.session.csrfToken) {
    return res.status(403).json({ success: false, message: 'Invalid or missing CSRF token.' });
  }
  return next();
}

// Only enforce CSRF on state-changing methods; GETs are safe/idempotent.
app.use((req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.path.startsWith('/api/') && req.path !== '/api/login') {
    return verifyCsrf(req, res, next);
  }
  return next();
});

// --- API routes ---
// Login/logout must be reachable without being authenticated.
// (Login itself is exempt from CSRF since there is no session yet.)
app.use('/api', authRoutes);
// Config and integration routes require an authenticated session.
app.use('/api', requireAuth, configRoutes);
app.use('/api', requireAuth, apiRoutes);

// --- Static assets (CSS/JS) are always public ---
app.use('/css', express.static(path.join(__dirname, 'public', 'css')));
app.use('/js', express.static(path.join(__dirname, 'public', 'js')));

// --- Public pages ---
app.get('/login.html', (req, res) => {
  res.sendFile ? null : null; // no-op guard (sendFile is on res via express)
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get(['/', '/index.html'], (req, res) => {
  // Root redirects to the dashboard if logged in, otherwise to login.
  if (req.session && req.session.user) {
    return res.redirect('/dashboard.html');
  }
  return res.redirect('/login.html');
});

// --- Protected pages ---
app.get('/dashboard.html', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/setup.html', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'setup.html'));
});

// --- Fallback 404 ---
app.use((req, res) => {
  res.status(404).send('Not found');
});

// Bind explicitly to 0.0.0.0 so the app is reachable from outside the
// host (e.g. http://<your-vps-ip>:1000), not just from localhost.
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Pterodactyl Port Manager running on port ${PORT}`);
  console.log(`Local access:    http://localhost:${PORT}`);
  console.log(`Network access:  http://<your-vps-ip>:${PORT}`);
  console.log('If this is unreachable externally, make sure your firewall allows inbound TCP on this port.');
});
