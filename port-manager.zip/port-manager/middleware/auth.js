/**
 * Authentication middleware.
 *
 * Protects routes/pages that require a logged-in user. If the session
 * does not contain an authenticated user, the request is redirected to
 * the login page (for page requests) or rejected with 401 (for API/XHR
 * requests).
 */

function requireAuth(req, res, next) {
  // A logged-in user has req.session.user set during login.
  if (req.session && req.session.user) {
    return next();
  }

  // If the client expects JSON (API call from dashboard.js), send a
  // structured error instead of an HTML redirect so the frontend can
  // react appropriately (e.g. show a message and redirect via JS).
  if (req.xhr || req.headers.accept === 'application/json' || req.originalUrl.startsWith('/api/')) {
    return res.status(401).json({ success: false, message: 'Not authenticated. Please log in again.' });
  }

  // Otherwise, redirect the browser to the login page.
  return res.redirect('/login.html');
}

module.exports = { requireAuth };
