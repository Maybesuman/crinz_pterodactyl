/**
 * Dashboard client-side logic.
 *
 * Handles the "Assign Port" workflow (calls the backend which talks to
 * the Pterodactyl Application API), the "Clear" button, and logout.
 */

const assignForm = document.getElementById('assignForm');
const statusMessage = document.getElementById('statusMessage');
const responseBox = document.getElementById('responseBox');
const assignBtn = document.getElementById('assignBtn');
const assignSpinner = document.getElementById('assignSpinner');
const assignBtnText = document.getElementById('assignBtnText');
const clearBtn = document.getElementById('clearBtn');
const logoutBtn = document.getElementById('logoutBtn');

let submitting = false; // guards against duplicate/concurrent requests
let csrfToken = null; // CSRF token for this session, required on POST requests

// Fetch a CSRF token for this session before any state-changing request.
async function loadCsrfToken() {
  try {
    const res = await fetch('/api/csrf-token');
    if (res.status === 401) {
      window.location.href = '/login.html';
      return;
    }
    const data = await res.json();
    if (data.success) csrfToken = data.csrfToken;
  } catch (err) {
    // Non-fatal; the follow-up request will surface a clear error.
  }
}
loadCsrfToken();

// Display a status banner (success or error).
function showStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = `status-message visible ${type}`;
}

function hideStatus() {
  statusMessage.classList.remove('visible');
}

// Show the raw API response for transparency/debugging.
function showResponse(data) {
  responseBox.textContent = JSON.stringify(data, null, 2);
  responseBox.classList.add('visible');
}

function hideResponse() {
  responseBox.classList.remove('visible');
  responseBox.textContent = '';
}

// Toggle the loading state of the Assign Port button.
function setLoading(isLoading) {
  assignBtn.disabled = isLoading;
  assignSpinner.classList.toggle('visible', isLoading);
  assignBtnText.textContent = isLoading ? 'Assigning...' : 'Assign Port';
}

// Handle form submission -> POST /api/assign-port.
assignForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (submitting) return; // prevent duplicate requests while one is in flight
  submitting = true;
  setLoading(true);
  hideStatus();
  hideResponse();

  const serverId = document.getElementById('serverId').value.trim();
  const nodeIp = document.getElementById('nodeIp').value.trim();
  const port = document.getElementById('port').value.trim();

  if (!serverId || !nodeIp || !port) {
    showStatus('All fields are required.', 'error');
    submitting = false;
    setLoading(false);
    return;
  }

  try {
    const res = await fetch('/api/assign-port', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken || '',
      },
      body: JSON.stringify({ serverId, nodeIp, port }),
    });

    if (res.status === 401) {
      window.location.href = '/login.html';
      return;
    }

    const data = await res.json();

    if (data.success) {
      showStatus(data.message || 'Port assigned successfully.', 'success');
    } else {
      showStatus(data.message || 'Failed to assign port.', 'error');
    }
    showResponse(data);
  } catch (err) {
    showStatus('Could not reach the server. Please try again.', 'error');
  } finally {
    submitting = false;
    setLoading(false);
  }
});

// Clear button - resets the form and hides messages.
clearBtn.addEventListener('click', () => {
  assignForm.reset();
  hideStatus();
  hideResponse();
});

// Logout button - destroys the session and redirects to login.
logoutBtn.addEventListener('click', async () => {
  logoutBtn.disabled = true;
  try {
    await fetch('/api/logout', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken || '' },
    });
  } catch (err) {
    // Even if the request fails, still redirect - the client should not
    // be stuck on the dashboard.
  } finally {
    window.location.href = '/login.html';
  }
});
